# handlers.py

import os
import sys
import json
import datetime
import base64
import requests

import config
import api_client
import utils

def select_model(api_key: str, engine: str, task: str) -> str:
    """Allows the user to select a model or use the default."""
    default_model = ""
    if task == 'chat':
        default_model = config.DEFAULT_OPENAI_CHAT_MODEL if engine == 'openai' else config.DEFAULT_GEMINI_MODEL
    elif task == 'image':
        default_model = config.DEFAULT_OPENAI_IMAGE_MODEL

    use_default = input(f"Use default model ({default_model})? (Y/n): ").lower().strip()
    if use_default in ('', 'y', 'yes'):
        return default_model

    print("Fetching available models...")
    models = api_client.fetch_available_models(api_key, engine, task)
    if not models:
        print(f"Using default: {default_model}", file=sys.stderr)
        return default_model

    print("\nPlease select a model:")
    for i, model_name in enumerate(models):
        print(f"  {i+1}. {model_name}")

    try:
        choice = input(f"Enter number (or press Enter for default): ")
        if not choice: return default_model
        index = int(choice) - 1
        if 0 <= index < len(models):
            return models[index]
    except (ValueError, IndexError):
        pass

    print(f"Invalid selection. Using default: {default_model}")
    return default_model

def _perform_single_shot_chat(api_key: str, engine: str, model: str, messages_or_contents: list, max_tokens: int, session_raw_logs: list | None = None) -> tuple[str, str]:
    """
    Executes a single chat request with a pre-constructed message list
    and returns the response and token string.
    """
    response_data = None
    if engine == 'openai':
        url, headers, payload = "https://api.openai.com/v1/chat/completions", {"Authorization": f"Bearer {api_key}"}, {"model": model, "messages": messages_or_contents}
        if max_tokens:
            if any(prefix in model for prefix in ['gpt-3.5', 'gpt-4']):
                payload['max_tokens'] = max_tokens
            else:
                payload['max_completion_tokens'] = max_tokens
        response_data = api_client.make_api_request(url, headers, payload, session_raw_logs)

    elif engine == 'gemini':
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}"
        headers = {"Content-Type": "application/json"}
        payload = {"contents": messages_or_contents}
        if max_tokens:
            payload['generationConfig'] = {'maxOutputTokens': max_tokens}
        response_data = api_client.make_api_request(url, headers, payload, session_raw_logs)

    if not response_data:
        return "", " [0/0/0/0]"

    assistant_response = ""
    if engine == 'openai' and 'choices' in response_data:
        assistant_response = response_data['choices'][0]['message']['content']
    elif engine == 'gemini' and 'candidates' in response_data:
        try:
            assistant_response = response_data['candidates'][0]['content']['parts'][0]['text']
        except (KeyError, IndexError):
            finish_reason = response_data['candidates'][0].get('finishReason', 'UNKNOWN')
            print(f"Warning: Could not extract Gemini response part. Finish reason: {finish_reason}", file=sys.stderr)
            assistant_response = "" 

    p, c, r, t = utils.parse_token_counts(engine, response_data)
    token_str = f" [{p}/{c}/{r}/{t}]"
    return assistant_response, token_str

def _handle_slash_command(user_input: str, state: dict) -> bool:
    """
    Handles in-app slash commands. Returns True if the session should end.
    """
    command = user_input.lower().strip()

    if command == '/exit':
        return True
    
    elif command == '/debug':
        state['debug_active'] = not state['debug_active']
        status = "ENABLED" if state['debug_active'] else "DISABLED"
        print(f"--> Session-specific debug logging is now {status}.")
    
    elif command == '/clear':
        confirm = input("This will clear all conversation history, including initial context. If you're sure, type `proceed`: ")
        if confirm.lower() == 'proceed':
            state['history'].clear()
            state['system_prompt'] = None
            state['initial_image_data'].clear()
            print("--> All context has been cleared.")
        else:
            print("--> Clear cancelled.")

    elif command == '/forget':
        state['history'].clear()
        print("--> Conversation history forgotten. Initial context remains.")

    elif command == '/model':
        state['model'] = select_model(state['api_key'], state['engine'], 'chat')
        print(f"--> Model changed to: {state['model']}")

    elif command == '/engine':
        new_engine = 'gemini' if state['engine'] == 'openai' else 'openai'
        try:
            new_api_key = api_client.check_api_keys(new_engine)
            state['history'] = utils.translate_history(state['history'], new_engine)
            state['engine'] = new_engine
            state['api_key'] = new_api_key
            state['model'] = config.DEFAULT_OPENAI_CHAT_MODEL if new_engine == 'openai' else config.DEFAULT_GEMINI_MODEL
            print(f"--> Engine switched to {state['engine'].capitalize()}. Model set to default: {state['model']}. History translated for compatibility.")
        except SystemExit:
             print(f"--> Switch to {new_engine.capitalize()} failed: API key not found.")
    
    else:
        print(f"--> Unknown command: {command}")

    return False

def _perform_interactive_chat(api_key: str, engine: str, model: str, system_prompt: str, initial_image_data: list, session_name: str, max_tokens: int):
    if session_name:
        log_filename_base = f"{session_name}.jsonl"
    else:
        log_filename_base = f"chat_{datetime.datetime.now().strftime('%Y%m%d-%H%M%S')}_{engine}.jsonl"
    log_filename = os.path.join(config.LOG_DIRECTORY, log_filename_base)

    print(f"Starting interactive chat with {engine.capitalize()} ({model}). Type '/exit' to end.")
    print(f"Available commands: /exit, /debug, /clear, /forget, /model, /engine")
    print(f"Session log will be saved to: {log_filename}")

    session_state = {
        'api_key': api_key,
        'engine': engine,
        'model': model,
        'system_prompt': system_prompt,
        'initial_image_data': initial_image_data,
        'history': [],
        'debug_active': False,
        'session_raw_logs': []
    }
    
    if system_prompt: print("System prompt is active.")
    if initial_image_data: print(f"Attached {len(initial_image_data)} image(s) to this session.")

    first_turn = True
    try:
        while True:
            user_input = input("\nYou: ")
            if not user_input.strip(): continue

            if user_input.startswith('/'):
                if _handle_slash_command(user_input, session_state):
                    break 
                continue

            # Build the full message list for the API call
            messages_or_contents = []
            if session_state['engine'] == 'openai':
                messages_or_contents.extend(session_state['history'])
                user_content = [{"type": "text", "text": user_input}]
                if first_turn and session_state['initial_image_data']:
                    for img in session_state['initial_image_data']:
                        user_content.append({"type": "image_url", "image_url": {"url": f"data:{img['mime_type']};base64,{img['data']}"}})
                messages_or_contents.append({"role": "user", "content": user_content})
                if session_state['system_prompt']:
                    messages_or_contents.insert(0, {"role": "system", "content": session_state['system_prompt']})
            else: # gemini
                messages_or_contents.extend(session_state['history'])
                user_parts = [{"text": user_input}]
                if first_turn and session_state['initial_image_data']:
                    for img in session_state['initial_image_data']:
                        user_parts.append({"inline_data": {"mime_type": img['mime_type'], "data": img['data']}})
                messages_or_contents.append({"role": "user", "parts": user_parts})
                if session_state['system_prompt']:
                     messages_or_contents.insert(0, {"role": "model", "parts": [{"text": "Okay."}]})
                     messages_or_contents.insert(0, {"role": "user", "parts": [{"text": session_state['system_prompt']}]})
            
            srl_list = session_state['session_raw_logs'] if session_state['debug_active'] else None
            
            response, token_str = _perform_single_shot_chat(
                api_key=session_state['api_key'],
                engine=session_state['engine'],
                model=session_state['model'],
                messages_or_contents=messages_or_contents,
                max_tokens=max_tokens,
                session_raw_logs=srl_list
            )
            print(f"\nAssistant: {response}{token_str}")
            
            # Construct message objects for history
            user_msg = messages_or_contents[-1]
            if session_state['engine'] == 'openai':
                asst_msg = {"role": "assistant", "content": response}
            else:
                asst_msg = {"role": "model", "parts": [{"text": response}]}

            session_state['history'].extend([user_msg, asst_msg])
            
            try:
                p, c, r, t = map(int, token_str.strip(' []').split('/'))
            except ValueError:
                p, c, r, t = 0,0,0,0

            log_entry = {"timestamp": datetime.datetime.now().isoformat(), "model": session_state['model'], "prompt": user_msg, "response": asst_msg, "tokens": {"prompt": p, "completion": c, "reasoning": r, "total": t}}
            with open(log_filename, 'a', encoding='utf-8') as f:
                f.write(json.dumps(log_entry) + '\n')

            if len(session_state['history']) > config.MAX_HISTORY_TURNS * 2:
                session_state['history'] = session_state['history'][-(config.MAX_HISTORY_TURNS * 2):]
            
            first_turn = False

    except (KeyboardInterrupt, EOFError):
        print("\nSession interrupted.")
    finally:
        print("\nSession ended.")
        if os.path.exists(log_filename):
            _update_persistent_memory(session_state['api_key'], session_state['engine'], session_state['model'], log_filename)
            if not session_name:
                rename_session_log(session_state['api_key'], session_state['engine'], log_filename)
        
        if session_state['debug_active']:
            debug_filename = f"debug_{os.path.splitext(log_filename_base)[0]}.jsonl"
            debug_filepath = os.path.join(config.LOG_DIRECTORY, debug_filename)
            print(f"Saving debug log to: {debug_filepath}")
            with open(debug_filepath, 'w', encoding='utf-8') as f:
                for entry in session_state['session_raw_logs']:
                    f.write(json.dumps(entry) + '\n')

def _update_persistent_memory(api_key: str, engine: str, model: str, log_file: str):
    """
    Automatically summarizes the session and integrates it into the persistent memory.
    """
    try:
        print("Summarizing session for memory...")
        with open(log_file, 'r', encoding='utf-8') as f:
            log_content = f.read()
        
        summary_prompt = "Provide a concise, third-person summary of the key topics, facts, and outcomes from the following chat log. Focus on information worth remembering for future sessions.\n" + f"CHAT LOG:\n---\n{log_content}\n---"
        
        # Build messages list for the summary call
        messages_or_contents = []
        if engine == 'openai':
            messages_or_contents = [{"role": "user", "content": summary_prompt}]
        else:
            messages_or_contents = [{"role": "user", "parts": [{"text": summary_prompt}]}]

        summary_text, _ = _perform_single_shot_chat(api_key, engine, model, messages_or_contents, 1024)
        
        if not summary_text:
            print("Warning: Failed to generate session summary. Memory not updated.", file=sys.stderr)
            return

        print("Updating persistent memory...")
        existing_ltm = ""
        if os.path.exists(config.PERSISTENT_MEMORY_FILE):
            with open(config.PERSISTENT_MEMORY_FILE, 'r', encoding='utf-8') as f:
                existing_ltm = f.read()

        integration_prompt = (
            "You are a memory consolidation agent. Integrate the new session summary into the existing persistent memory. "
            "Combine related topics, update existing facts, and discard trivial data to keep the memory concise and relevant. "
            "The goal is a dense, factual summary of all interactions.\n\n"
            f"--- EXISTING PERSISTENT MEMORY ---\n{existing_ltm}\n\n"
            f"--- NEW SESSION SUMMARY TO INTEGRATE ---\n{summary_text}\n\n"
            "--- UPDATED PERSISTENT MEMORY ---"
        )
        
        task_model = config.DEFAULT_HELPER_MODEL_OPENAI if engine == 'openai' else config.DEFAULT_HELPER_MODEL_GEMINI
        
        # Build messages list for the integration call
        if engine == 'openai':
            messages_or_contents = [{"role": "user", "content": integration_prompt}]
        else:
            messages_or_contents = [{"role": "user", "parts": [{"text": integration_prompt}]}]
            
        updated_ltm, _ = _perform_single_shot_chat(api_key, engine, task_model, messages_or_contents, None)

        if updated_ltm:
            with open(config.PERSISTENT_MEMORY_FILE, 'w', encoding='utf-8') as f:
                f.write(updated_ltm.strip())
            print("Persistent memory updated successfully.")
        else:
            print("Warning: Failed to update persistent memory.", file=sys.stderr)

    except Exception as e:
        print(f"Error during memory update: {e}", file=sys.stderr)

def rename_session_log(api_key: str, engine: str, log_file: str):
    """
    Generates a descriptive name for the chat log using an AI model and renames the file.
    """
    print("Generating smart name for session log...")
    try:
        with open(log_file, 'r', encoding='utf-8') as f:
            log_content = "".join(f.readlines()[:50]) 

        prompt = (
            "Based on the following chat log, generate a concise, descriptive, filename-safe title. "
            "Use snake_case. The title should be 3-5 words. Do not include any file extension like '.jsonl'. "
            "Example response: 'python_script_debugging_and_refactoring'\n\n"
            f"CHAT LOG:\n---\n{log_content}\n---"
        )
        
        task_model = config.DEFAULT_HELPER_MODEL_OPENAI if engine == 'openai' else config.DEFAULT_HELPER_MODEL_GEMINI
        
        if engine == 'openai':
            messages_or_contents = [{"role": "user", "content": prompt}]
        else:
            messages_or_contents = [{"role": "user", "parts": [{"text": prompt}]}]
            
        new_name, _ = _perform_single_shot_chat(api_key, engine, task_model, messages_or_contents, 50)
        sanitized_name = utils.sanitize_filename(new_name.strip())
        
        if sanitized_name:
            new_filename_base = f"{sanitized_name}.jsonl"
            new_filepath = os.path.join(config.LOG_DIRECTORY, new_filename_base)
            
            counter = 1
            while os.path.exists(new_filepath):
                new_filename_base = f"{sanitized_name}_{counter}.jsonl"
                new_filepath = os.path.join(config.LOG_DIRECTORY, new_filename_base)
                counter += 1

            os.rename(log_file, new_filepath)
            print(f"Session log saved as: {new_filepath}")
        else:
            print(f"Warning: Could not generate a valid name. Log remains as: {log_file}", file=sys.stderr)

    except (IOError, OSError, Exception) as e:
        print(f"Warning: Could not rename session log ({e}). Log remains as: {log_file}", file=sys.stderr)

def handle_chat(api_key: str, engine: str, model: str, system_prompt: str, initial_prompt: str, image_data: list, session_name: str, max_tokens: int):
    """Handles both single-shot and interactive chat sessions."""
    # This function now only handles the initial, single-shot case.
    # Interactive chat is handled by _perform_interactive_chat.
    if initial_prompt:
        messages_or_contents = []
        if engine == 'openai':
            user_content = [{"type": "text", "text": initial_prompt}]
            for img in image_data:
                user_content.append({"type": "image_url", "image_url": {"url": f"data:{img['mime_type']};base64,{img['data']}"}})
            messages_or_contents = [{"role": "user", "content": user_content}]
            if system_prompt:
                messages_or_contents.insert(0, {"role": "system", "content": system_prompt})
        else: # gemini
            user_parts = [{"text": initial_prompt}]
            for img in image_data:
                user_parts.append({"inline_data": {"mime_type": img['mime_type'], "data": img['data']}})
            messages_or_contents = [{"role": "user", "parts": user_parts}]
            if system_prompt:
                messages_or_contents.insert(0, {"role": "model", "parts": [{"text": "Okay."}]})
                messages_or_contents.insert(0, {"role": "user", "parts": [{"text": system_prompt}]})
        
        response, token_str = _perform_single_shot_chat(api_key, engine, model, messages_or_contents, max_tokens)
        print(response + token_str)
    else:
        _perform_interactive_chat(api_key, engine, model, system_prompt, image_data, session_name, max_tokens)

def handle_both_engines(openai_key: str, gemini_key: str, system_prompt: str, prompt: str, image_data: list, max_tokens: int):
    """Sends a single-shot prompt to both OpenAI and Gemini and prints the results."""
    print("--- OpenAI Response ---")
    openai_model = select_model(openai_key, 'openai', 'chat')
    
    openai_user_content = [{"type": "text", "text": prompt}]
    for img in image_data:
        openai_user_content.append({"type": "image_url", "image_url": {"url": f"data:{img['mime_type']};base64,{img['data']}"}})
    openai_messages = [{"role": "user", "content": openai_user_content}]
    if system_prompt:
        openai_messages.insert(0, {"role": "system", "content": system_prompt})
    
    openai_response, openai_tokens = _perform_single_shot_chat(openai_key, 'openai', openai_model, openai_messages, max_tokens)
    print(openai_response + openai_tokens)
    print("\n" + "="*50 + "\n")

    print("--- Gemini Response ---")
    gemini_model = select_model(gemini_key, 'gemini', 'chat')
    
    gemini_user_parts = [{"text": prompt}]
    for img in image_data:
        gemini_user_parts.append({"inline_data": {"mime_type": img['mime_type'], "data": img['data']}})
    gemini_contents = [{"role": "user", "parts": gemini_user_parts}]
    if system_prompt:
        gemini_contents.insert(0, {"role": "model", "parts": [{"text": "Okay."}]})
        gemini_contents.insert(0, {"role": "user", "parts": [{"text": system_prompt}]})
        
    gemini_response, gemini_tokens = _perform_single_shot_chat(gemini_key, 'gemini', gemini_model, gemini_contents, max_tokens)
    print(gemini_response + gemini_tokens)
    print("\n" + "="*50 + "\n")

def handle_image_generation(api_key: str, prompt: str):
    """Handles OpenAI image generation."""
    model = select_model(api_key, 'openai', 'image')
    if not prompt:
        if sys.stdin.isatty():
             prompt = input("Enter a description for the image: ")
        else:
            prompt = sys.stdin.read().strip()

    if not prompt:
        print("Image generation cancelled: No prompt provided.", file=sys.stderr)
        return

    print(f"Generating image with {model} for prompt: '{prompt}'...")
    
    payload = {
        "model": model,
        "prompt": prompt,
        "n": 1,
        "size": "1024x1024"
    }
    
    if model.startswith('dall-e'):
        payload['response_format'] = 'b64_json'
        
    url, headers = "https://api.openai.com/v1/images/generations", {"Authorization": f"Bearer {api_key}"}
    response_data = api_client.make_api_request(url, headers, payload)

    if response_data and 'data' in response_data:
        image_url = response_data['data'][0].get('url')
        b64_data = response_data['data'][0].get('b64_json')
        image_bytes = None
        
        if b64_data:
            try:
                image_bytes = base64.b64decode(b64_data)
            except base64.binascii.Error as e:
                print(f"Error decoding base64 image data: {e}", file=sys.stderr)
                return
        elif image_url:
            try:
                print(f"Downloading image from: {image_url}")
                image_response = requests.get(image_url)
                image_response.raise_for_status()
                image_bytes = image_response.content
            except requests.exceptions.RequestException as e:
                print(f"Error downloading image: {e}", file=sys.stderr)
                return
        
        if image_bytes:
            try:
                safe_prompt = utils.sanitize_filename(prompt[:50])
                base_filename = f"image_{safe_prompt}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
                filepath = os.path.join(config.IMAGE_DIRECTORY, base_filename)
                
                with open(filepath, 'wb') as f:
                    f.write(image_bytes)
                print(f"Image saved successfully as: {filepath}")
                log_entry = {
                    "timestamp": datetime.datetime.now().isoformat(),
                    "model": model,
                    "prompt": prompt,
                    "file": filepath
                }
                with open(config.IMAGE_LOG_FILE, 'a', encoding='utf-8') as f:
                    f.write(json.dumps(log_entry) + '\n')
            except IOError as e:
                print(f"Error saving image to file: {e}", file=sys.stderr)
        else:
            print("Error: API response did not contain image data in a recognized format (URL or b64_json).", file=sys.stderr)
    else:
        print("Image generation failed.", file=sys.stderr)
