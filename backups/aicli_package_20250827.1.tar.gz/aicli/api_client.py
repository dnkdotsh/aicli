# api_client.py

import os
import sys
import json
import requests
import datetime
import config

def check_api_keys(engine: str):
    """Checks for the required API key in environment variables and returns it."""
    key_name = 'OPENAI_API_KEY' if engine == 'openai' else 'GEMINI_API_KEY'
    api_key = os.getenv(key_name)
    if not api_key:
        print(f"Error: Environment variable '{key_name}' is not set.", file=sys.stderr)
        sys.exit(1)
    return api_key

def make_api_request(url: str, headers: dict, payload: dict, session_raw_logs: list | None = None) -> dict:
    """Makes a POST request to the specified API endpoint and handles errors."""
    response_data = None
    error_info = None

    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        response_data = response.json()
        if 'error' in response_data:
            print(f"API Error: {response_data['error'].get('message', 'Unknown error')}", file=sys.stderr)
            error_info = response_data['error']
            return None
        return response_data
    except requests.exceptions.HTTPError as e:
        error_details = "No specific error message provided by the API."
        try:
            error_details = e.response.json()['error']['message']
        except (json.JSONDecodeError, KeyError, AttributeError):
            error_details = e.response.text
        print(f"HTTP Request Error: {e}\nDETAILS: {error_details}", file=sys.stderr)
        error_info = {"code": e.response.status_code, "message": error_details}
        return None
    except requests.exceptions.RequestException as e:
        print(f"HTTP Request Error: {e}", file=sys.stderr)
        error_info = {"message": str(e)}
        return None
    except json.JSONDecodeError:
        print("Error: Failed to decode API response.", file=sys.stderr)
        error_info = {"message": "Failed to decode API response."}
        return None
    finally:
        # Log the raw request and response unconditionally
        log_entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "request": {"url": url, "headers": headers, "payload": payload},
            "response": response_data or {"error": error_info}
        }
        with open(config.RAW_LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(json.dumps(log_entry) + '\n')
        
        # If a session-specific log list is provided, append to it
        if session_raw_logs is not None:
            session_raw_logs.append(log_entry)

def fetch_available_models(api_key: str, engine: str, task: str) -> list[str]:
    """Fetches a list of available models from the API."""
    try:
        if engine == 'openai':
            url, headers = "https://api.openai.com/v1/models", {"Authorization": f"Bearer {api_key}"}
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            model_list = response.json().get('data', [])
            model_ids = [m['id'] for m in model_list]

            if task == 'chat':
                chat_models = [mid for mid in model_ids if mid.startswith('gpt')]
                return sorted(chat_models)
            
            elif task == 'image':
                # --- THIS IS THE FIX ---
                image_models = [mid for mid in model_ids if mid.startswith('dall-e') or 'image' in mid]
                return sorted(image_models)

        elif engine == 'gemini':
            url = f"https://generativelanguage.googleapis.com/v1beta/models?key={api_key}"
            response = requests.get(url)
            response.raise_for_status()
            model_list = response.json().get('models', [])
            return sorted([m['name'].replace('models/', '') for m in model_list if 'generateContent' in m.get('supportedGenerationMethods', [])])
            
    except requests.exceptions.RequestException as e:
        print(f"\nWarning: Could not fetch model list ({e}).", file=sys.stderr)
        return []
    return []

